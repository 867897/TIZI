#!/bin/bash
cd `dirname $0`
if command -v python3 >/dev/null 2>&1; then
	python_ver="$(command -v python3)"
elif command -v python >/dev/null 2>&1; then
	python_ver="$(command -v python)"
elif command -v python2 >/dev/null 2>&1; then
	python_ver="$(command -v python2)"
else
	echo "python3 is required"
	exit 1
fi
eval $(ps -ef | grep -E "[0-9] .*/python(2|3)? server\\.py a" | awk '{print "kill "$2}')
ulimit -n 512000
nohup "${python_ver}" server.py a >> /dev/null 2>&1 &
